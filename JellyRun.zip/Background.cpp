#include "pch.h"
#include "Background.h"

CBackground::CBackground()
{
    m_BackgroundX = 0;
}

CBackground::~CBackground()
{
}

void CBackground::LoadBackground(UINT resourceID)
{
    m_Background.LoadBitmap(resourceID);
}

void CBackground::Update()
{
    m_BackgroundX -= BACKGROUND_SPEED;

    if (m_BackgroundX <= -1600)  // ��� �ʺ� ����
        m_BackgroundX = 0;
}

void CBackground::Draw(CDC* pDC)
{
    if (m_Background.m_hObject == NULL)  // ��Ʈ���� ��ȿ���� üũ
    {
        AfxMessageBox(_T("��Ʈ�� �ڵ��� NULL�Դϴ�!"));
        return;
    }

    // ��Ʈ�� ���� ���
    BITMAP bmpInfo;
    m_Background.GetBitmap(&bmpInfo);

    int bmpW = bmpInfo.bmWidth;
    int bmpH = bmpInfo.bmHeight;

    int scaledW = bmpW * 2;
    int scaledH = bmpH * 2;


    CBitmap* pOldBitmap;
    CDC memDC;
    memDC.CreateCompatibleDC(pDC);

    pOldBitmap = memDC.SelectObject(&m_Background);

    // ����� 2�� Ȯ���ؼ� 2�� �̾���̱�
    pDC->StretchBlt(m_BackgroundX, 0, scaledW, scaledH, &memDC, 0, 0, bmpW, bmpH, SRCCOPY);
    pDC->StretchBlt(m_BackgroundX + scaledW, 0, scaledW, scaledH, &memDC, 0, 0, bmpW, bmpH, SRCCOPY);

    memDC.SelectObject(pOldBitmap);
}
