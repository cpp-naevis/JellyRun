﻿// NameInputDlg.cpp: 구현 파일
//

#include "pch.h"
#include "JellyRun.h"
#include "afxdialogex.h"
#include "NameInputDlg.h"


// NameInputDlg 대화 상자

IMPLEMENT_DYNAMIC(NameInputDlg, CDialogEx)

NameInputDlg::NameInputDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG_NAMEINPUT, pParent)
{

}

NameInputDlg::~NameInputDlg()
{
}

void NameInputDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_NAME, m_userName); // Edit Control 연결
}


BEGIN_MESSAGE_MAP(NameInputDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_INPUT, &NameInputDlg::OnBnClickedButtonInput)
    ON_WM_CTLCOLOR()
    ON_WM_DRAWITEM()
END_MESSAGE_MAP()


// NameInputDlg 메시지 처리기
void NameInputDlg::OnBnClickedButtonInput()
{
	UpdateData(TRUE);  // 입력값 m_userName에 저장
	EndDialog(IDOK);   // 다이얼로그 닫기
}

BOOL NameInputDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    // ------폰트 설정------
    // 제목 닉네임
    m_fontTitle.CreateFont(32, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0,
        HANGEUL_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, _T("Pretendard"));

    // 부제목 닉네임을 입력하세요
    m_fontDesc.CreateFont(20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
        HANGEUL_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, _T("Pretendard"));

    m_fontEdit.CreateFont(20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
        HANGEUL_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, _T("Pretendard"));

    m_fontButton.CreateFont(20, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0,
        HANGEUL_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, _T("Pretendard"));

    // 폰트 적용
    GetDlgItem(IDC_STATIC_NICKNAME)->SetFont(&m_fontTitle);
    GetDlgItem(IDC_STATIC)->SetFont(&m_fontDesc);
    GetDlgItem(IDC_EDIT_NAME)->SetFont(&m_fontEdit);
    GetDlgItem(IDC_BUTTON_INPUT)->ModifyStyle(0, BS_OWNERDRAW); // 버튼 스타일 강제 적용 (Owner Draw)

    // 입력창 배경색용 브러시
    m_brEditBg.CreateSolidBrush(RGB(225, 240, 255));  // 하늘색 배경

    return TRUE;
}

// 닉네임 입력창 배경색 설정
HBRUSH NameInputDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
    if (pWnd->GetDlgCtrlID() == IDC_EDIT_NAME)
    {
        pDC->SetBkColor(RGB(225, 240, 255));
        pDC->SetTextColor(RGB(0, 0, 0)); // 검정색 글씨
        return (HBRUSH)m_brEditBg;
    }

    return CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);
}

// 둥근 버튼
void NameInputDlg::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
    AfxMessageBox(_T("DrawItem 호출됨"));

    if (lpDrawItemStruct->CtlID == IDC_BUTTON_INPUT)
    {
        CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
        CRect rect = lpDrawItemStruct->rcItem;

        CBrush brush(RGB(16, 0, 128)); // 남색
        CPen pen(PS_SOLID, 1, RGB(16, 0, 128));

        CBrush* pOldBrush = pDC->SelectObject(&brush);
        CPen* pOldPen = pDC->SelectObject(&pen);

        pDC->RoundRect(rect, CPoint(15, 15));

        // 텍스트 출력
        CString text;
        GetDlgItem(IDC_BUTTON_INPUT)->GetWindowText(text);
        pDC->SetBkMode(TRANSPARENT);
        pDC->SetTextColor(RGB(255, 255, 255));
        pDC->DrawText(text, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

        pDC->SelectObject(pOldBrush);
        pDC->SelectObject(pOldPen);
    }
}
