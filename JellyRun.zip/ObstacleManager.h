#pragma once
#include <vector>
#include "Obstacle.h"

class CObstacleManager
{
private:
    std::vector<CObstacle*> obstacles;
    int spawnCounter = 0;

public:
    ~CObstacleManager();
    void Update();
    void Draw(CDC* pDC);
    void SpawnObstacle();
    bool CheckCollision(const CRect& targetRect);
};

